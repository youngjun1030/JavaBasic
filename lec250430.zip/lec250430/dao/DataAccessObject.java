package lec250430.dao;

public interface DataAccessObject {
	void select();
	void insert();
	void update();
	void delete();
}
