package lec250430.countable;

public interface countable {
	void count();
}
