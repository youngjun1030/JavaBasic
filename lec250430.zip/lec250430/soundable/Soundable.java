package lec250430.soundable;

public interface Soundable {
	String sound();
}
