package lec250430.soundable;

public class Dog implements Soundable{

	@Override
	public String sound() {
		return "멍멍";
	}

}
