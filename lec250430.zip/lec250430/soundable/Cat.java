package lec250430.soundable;

public class Cat implements Soundable{

	@Override
	public String sound() {
		return "야옹";
	}

}
