package hw250423;

public class TestCircle {
    public static void main(String[] args) {
        Circle c1 = new Circle(5);
        ColorCircle c2 = new ColorCircle(10, "빨간");

        c1.show();
        c2.show();
    }
}

